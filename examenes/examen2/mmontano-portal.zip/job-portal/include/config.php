<?php $categorias = array(
    "Marketing",
    "Customer Service",
    "Human Resource",
    "Project Managemen",
    "Business Development",
    "Sales & Communication",
    "Teaching & Education",
    "Design & Creative"
);
$localidades = array(
    "Alcudia",
    "Palma",
    "Binissalem",
    "Lloseta",
    "Santa Maria",
)?>