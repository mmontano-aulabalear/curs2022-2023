<h1>1.</h1>
<?php $asignaturas = array('Aplicaciones Web', 'Servicios en Red' ,
    'Sistemas Operativos en Red', 'Seguridad Informatica', 
    'Empresa e Iniciativa Emprendedora');
    foreach($asignaturas as $asignatura){
        echo "$asignatura <br>";}?>
<h1>2.</h1>
<?php echo "<h2>LUNES</h2>";$lunes = array('Sistemas Operativos en Red', 'Sistemas Operativos en Red' ,
    'Empresa e Iniciativa Emprendedora', 'Seguridad Informatica', 
    'Seguridad Informatica', 'Seguridad Informatica');
    foreach($lunes as $lunes_a){
        echo "$lunes_a <br>";}echo "<br>";
    echo "<h2>MARTES</h2>";$martes = array('Servicios en Red', 'Servicios en Red' ,
    'Servicios en Red', 'Servicios en Red', 
    'Servicios en Red', 'Aplicaciones Web');
    foreach($martes as $martes_a){
        echo "$martes_a <br>";}echo "<br>";
    echo "<h2>MIERCOLES</h2>";$miercoles = array('Empresa e Iniciativa Emprendedora', 'Empresa e Iniciativa Emprendedora' ,
    'Aplicaciones Web', 'Aplicaciones Web', 
    'Aplicaciones Web', 'Aplicaciones Web');
    foreach($miercoles as $miercoles_a){
        echo "$miercoles_a <br>";}echo "<br>";
    echo "<h2>JUEVES</h2>";$jueves = array('Seguridad Informatica', 'Seguridad Informatica' ,
    'Seguridad Informatica', 'Servicios en Red', 
    'Servicios en Red', 'Servicios en Red');
    foreach($jueves as $jueves_a){
        echo "$jueves_a <br>";}echo "<br>";
    echo "<h2>VIERNES</h2>";$viernes = array('Sistemas Operativos en Red', 'Sistemas Operativos en Red' ,
    'Sistemas Operativos en Red', 'Sistemas Operativos en Red', 
    'Sistemas Operativos en Red', 'Sistemas Operativos en Red');
    foreach($viernes as $viernes_a){
        echo "$viernes_a <br>";}echo "<br>";
?>