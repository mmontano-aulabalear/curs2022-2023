<?php for($i=1; $i<101; $i++){
    if ($i%3==0){
        echo "idò sí<br>";
    }
    elseif ($i%5==0){
        echo "baixa del carro<br>";
    }
    else{
        echo $i."<br>";
    }
}?>