<h1>7.</h1>
<?php echo "<h1>MICHAEL MONTAÑO MEJIA</h1><hr><br>
<img src=\"https://www.diputadodelcomun.org/wp-content/uploads/2019/09/user-256.png\">
<h2>Información personal</h2><hr><br>
Michael Montaño Mejia, 18 años<br>
Nacido en Santa Cruz, Argentina <strong>(2003)</strong><br>
Residente en Palma, Mallorca, Illes Balears<br>
Telefono fijo: 972384345 | Movil: 634082239<br>
Correo electronico: <a href=\"mailto:mmontano@alumnes.aulabalear.org\">mmontano@alumnes.aulabalear.org<a><br>
<h2>Formación Academica</h2><hr><br>
<ol>
    <li>Grado en ESO <strong>(2019)</strong></li>
    <li>Cursando CFGM en Sistemas microinformaticos y Redes <strong>(2021-2023)</strong></li>
</ol>
<h2>Actividades laborales</h2><hr><br>
<ul>
<li>Coempresario de la empresa KiwiTech <strong>(1 mes)</strong></li>
<li>Director de la empresa La Caja Informatica <strong>(2 meses)</strong></li>
</ul>
<h2>Datos de interés</h2><hr><br>
Persona seria y puntual<br>
Carnet de permiso B<br>
Persona dedicada al mundo de la informatica"?>