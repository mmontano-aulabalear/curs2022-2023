<?php $elmeunom=$_GET['nombre'];
echo "Hola ".$elmeunom?>