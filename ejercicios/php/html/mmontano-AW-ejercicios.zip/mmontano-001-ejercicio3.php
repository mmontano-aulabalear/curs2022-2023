<h1>5.</h1>
<?php $name="Michael Montaño Mejia";echo"Bienvenido a la programación
 PHP $name"?>
<h1>6.</h1>
Si cambiamos en mayusculas alguna letra de la variable daria el siguiente error:
<?php echo $Name?>