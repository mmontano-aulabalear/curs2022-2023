<?php $nombre=$_GET['nombre'];
$edad=$_GET['edad'];$ahora=date("Y");
echo "EDAD EN 2050: ",2050-$ahora+$edad?>